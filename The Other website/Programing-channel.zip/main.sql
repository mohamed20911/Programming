curl $REPLIT_DB_URL -d 'username=[username]'
