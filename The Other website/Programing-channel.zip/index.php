<!DOCTYPE html>
<html lang="en">
<head>
          <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
          <link rel="icon" type="image/png" href="/favicon.ico"/>
          <meta charset="Programing">
          <meta http-equiv="https://www.bing.com/?toWww=1&redig=3BA751C47BFC4D4D97AEAEE1B841F01C" content="IE=edge">
          <meta name="Programing" content="width=device-width, initial-scale=1.0">
          <link rel="stylesheet" href="style1.css">
          <title>Programing</title>
          <!-- script  -->
          <script src="script.js"></script>
</head>
<body id="P">
            <!-- <iframe src="https://giphy.com/embed/xThuWu82QD3pj4wvEQ" width="480" height="480" frameBorder="0" class="giphy-embed" allowFullScreen></iframe><p><a href="https://giphy.com/gifs/xThuWu82QD3pj4wvEQ">via GIPHY</a></p>
            <video autoplay muted loop id="myVideo">
                <source src="source.mp4" type="video/mp4"></source>
            </video> -->

            <!-- <div class="content">
            <h1>Heading</h1>
             <p>Lorem ipsum dolor sit amet, an his etiam torquatos. Tollit soleat phaedrum te duo, eum cu recteque expetendis neglegentur. Cu mentitum maiestatis persequeris pro, pri ponderum tractatos ei. Id qui nemore latine molestiae, ad mutat oblique delicatissimi pro.</p> 
            
            <button id="myBtn" onclick="myFunction()">Pause</button>
            
            </div> -->
          <div class="top">
                    <img src="logo.jpg" alt="" class="logo">
                    
                    <div>
                              <h1>Programing</h1>
                    </div>
                    
          </div>
          <div class="main">
                    <h1>Science has no end</h1>
                    <h2>How do you know what kind of Windows you have?</h2>
                    <video width="320" height="240" controls>
                              <source src="كيفيه معرفه الويندوز بتاعك 64 32bit.mp4" type="video/mp4">
                    </video>
                    <h2>How to download python on your computer ?</h2>
                    <video width="320" height="240" controls>
                              <source src="How to instal python on your computer.mp4" type="video/mp4">
                    </video>
                    <br>
                    <h3>Developers</h3>
                    <ol>
                        <a href="mailto:mohamed9919698@gmail.com" target="_blank"><li>Mohamed Ehab</li></a>
                    </ol>

            <!-- <details class="main">
                        <summery>Latest Video</summery>
                        <video width="320" height="240" controls>
                              <source src="" type="video/mp4">
                        </video>
            </detials> -->
                    <a href="m.me/Programming12345678">To contact me on Messenger</a>
          </div>

          <div class="side">
                    <ul>
                              <li><a href="index (1).php" target="_blank">LOGIN</a></li>
                              <li><a href="About.html" target="_blank">About</a></li>
                              <li><a href="Contact Us.html" target="_blank">Contact us</a></li>
                              <li><a href="Videos.html" target="_blank">Videos</a></li>
                              <li><a href="Channels.html" target="_blank">Channels I learn from it</a></li>
                              <li><a href="Projects.html">Projects</a></li>
                              <!-- <li><a href="App in projects.html" target="_blank">The Projects in apps</a></li> -->
                    </ul>
          </div>
</body>
</html>